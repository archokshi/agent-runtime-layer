"""Coding-agent integration adapters."""
